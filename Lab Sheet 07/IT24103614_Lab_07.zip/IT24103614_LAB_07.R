setwd("C:\\Users\\USER\\Desktop\\IT24103614_LAB_07")

## Question 1 – Uniform Distribution
# Train arrives uniformly between 0 and 40 minutes
# Part a: Probability train arrives between 10 and 25 minutes
punif(25, min=0, max=40) - punif(10, min=0, max=40)

# Part b: Probability train arrives after 25 minutes
# Method 1
1 - punif(25, min=0, max=40)
# Method 2 (using lower.tail=FALSE)
punif(25, min=0, max=40, lower.tail = FALSE)


## Question 2 – Exponential Distribution
# Time to complete software update is exponentially distributed with rate = 1/3
# Probability update takes at most 2 hours
pexp(2, rate = 1/3)


## Question 3 – Normal Distribution
# IQ ~ N(mean=100, sd=15)

# i. Probability IQ > 130
1 - pnorm(130, mean=100, sd=15)

# ii. IQ score at 95th percentile
qnorm(0.95, mean=100, sd=15)
